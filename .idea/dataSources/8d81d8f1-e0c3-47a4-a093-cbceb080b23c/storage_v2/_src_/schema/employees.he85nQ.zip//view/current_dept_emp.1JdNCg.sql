create view current_dept_emp as
  select `l`.`emp_no`    AS `emp_no`,
         `d`.`dept_no`   AS `dept_no`,
         `l`.`from_date` AS `from_date`,
         `l`.`to_date`   AS `to_date`
  from (`employees`.`dept_emp` `d` join `employees`.`dept_emp_latest_date` `l` on ((
    (`d`.`emp_no` = `l`.`emp_no`) and (`d`.`from_date` = `l`.`from_date`) and (`l`.`to_date` = `d`.`to_date`))));

